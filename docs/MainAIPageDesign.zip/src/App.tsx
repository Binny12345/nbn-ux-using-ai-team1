import { useState, useRef, useEffect } from "react";

const FILES = [
  { name: "requirements.txt", author: "User 2 (BA)", icon: "📄" },
  { name: "design_ideas.pdf", author: "User 3 (UX)", icon: "📄" },
  { name: "sprint_outline.pdf", author: "User 1 (PM)", icon: "📄" },
  { name: "wireframes_v2.docx", author: "User 3 (UX)", icon: "📄" },
];

type Message = {
  id: number;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
};

const INITIAL_MESSAGES: Message[] = [];

function formatTime() {
  const now = new Date();
  const h = now.getHours();
  const m = now.getMinutes().toString().padStart(2, "0");
  const ampm = h >= 12 ? "pm" : "am";
  return `${h % 12 || 12}:${m} ${ampm}`;
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [toastVisible, setToastVisible] = useState(true);
  const FILE_BADGE_COUNT = 3;
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function sendMessage() {
    const text = input.trim();
    if (!text) return;

    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      content: text,
      timestamp: formatTime(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

function handleTextareaInput(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 160) + "px";
  }

  return (
    <div
      className="flex flex-col size-full overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif", background: "#f8faff" }}
    >
      {/* Sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20"
          style={{ background: "rgba(0,0,0,0.18)" }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className="fixed top-0 left-0 h-full z-30 flex flex-col"
        style={{
          width: 300,
          background: "#fff",
          borderRight: "1.5px solid #e3ecff",
          transform: sidebarOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.28s cubic-bezier(0.4,0,0.2,1)",
          boxShadow: sidebarOpen ? "4px 0 32px rgba(26,108,255,0.1)" : "none",
        }}
      >
        <div
          className="flex items-center justify-between px-5 py-4"
          style={{ borderBottom: "1.5px solid #e3ecff" }}
        >
          <span
            className="font-semibold text-sm tracking-wide"
            style={{ color: "#1a6cff", letterSpacing: "0.06em" }}
          >
            PROJECT FILES
          </span>
          <button
            onClick={() => setSidebarOpen(false)}
            className="flex items-center justify-center rounded-lg w-8 h-8 transition-colors"
            style={{ color: "#8fa8d0" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              (e.currentTarget as HTMLElement).style.color = "#1a6cff";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
              (e.currentTarget as HTMLElement).style.color = "#8fa8d0";
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path
                d="M12 4L4 12M4 4l8 8"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          {FILES.map((file) => (
            <div
              key={file.name}
              className="flex items-start gap-3 px-5 py-3 cursor-pointer transition-colors group"
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "transparent";
              }}
            >
              <span className="text-base mt-0.5 select-none">{file.icon}</span>
              <div className="flex flex-col min-w-0">
                <span
                  className="text-sm font-medium truncate"
                  style={{ color: "#0f1c3f", fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {file.name}
                </span>
                <span
                  className="text-xs mt-0.5"
                  style={{ color: "#8fa8d0", fontFamily: "'Inter', sans-serif" }}
                >
                  {file.author}
                </span>
              </div>
            </div>
          ))}
        </div>
        <div className="shrink-0 px-4 py-3" style={{ borderTop: "1.5px solid #e3ecff" }}>
          <button
            className="w-full flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-colors"
            style={{
              background: "#f0f5ff",
              color: "#1a6cff",
              border: "1.5px dashed #b8d0ff",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#e3ecff";
              (e.currentTarget as HTMLElement).style.borderColor = "#1a6cff";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              (e.currentTarget as HTMLElement).style.borderColor = "#b8d0ff";
            }}
          >
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <path
                d="M7.5 10V3M4.5 5.5L7.5 3l3 2.5"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M2 11.5h11"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
              />
            </svg>
            Upload File
          </button>
        </div>
      </aside>

      {/* Header */}
      <header
        className="flex items-center gap-3 px-4 shrink-0"
        style={{
          height: 58,
          background: "#fff",
          borderBottom: "1.5px solid #e3ecff",
          zIndex: 10,
        }}
      >
        {/* Left group */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Return to menu */}
          <button
            className="flex items-center gap-1.5 text-sm font-medium rounded-lg px-3 py-2 transition-colors"
            style={{ color: "#1a6cff" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
            }}
          >
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <path
                d="M9.5 3L5 7.5l4.5 4.5"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            Menu
          </button>

          <div style={{ width: 1, height: 22, background: "#e3ecff" }} />

          {/* Sidebar toggle */}
          <div className="relative">
            <button
              onClick={() => setSidebarOpen(true)}
              className="flex items-center gap-1.5 text-sm font-medium rounded-lg px-3 py-2 transition-colors"
              style={{ color: "#4a6fa5" }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
                (e.currentTarget as HTMLElement).style.color = "#1a6cff";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "transparent";
                (e.currentTarget as HTMLElement).style.color = "#4a6fa5";
              }}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <rect x="2" y="3.5" width="12" height="1.5" rx="0.75" fill="currentColor" />
                <rect x="2" y="7.25" width="8" height="1.5" rx="0.75" fill="currentColor" />
                <rect x="2" y="11" width="10" height="1.5" rx="0.75" fill="currentColor" />
              </svg>
              Files
            </button>
            <span
              className="absolute flex items-center justify-center rounded-full text-white font-bold pointer-events-none"
              style={{
                top: 2,
                right: -4,
                minWidth: 18,
                height: 18,
                fontSize: 10,
                background: "#e03b3b",
                padding: "0 4px",
                lineHeight: 1,
                boxShadow: "0 1px 4px rgba(224,59,59,0.4)",
              }}
            >
              {FILE_BADGE_COUNT}
            </span>
          </div>
        </div>

        {/* Center — project name + timestamp */}
        <div className="flex-1 flex flex-col items-center justify-center min-w-0">
          <span
            className="font-semibold text-sm leading-tight"
            style={{ color: "#0f1c3f" }}
          >
            AI Workspace Project
          </span>
          <span
            className="text-xs leading-tight"
            style={{ color: "#8fa8d0" }}
          >
            Last edited 27/08/2026 at 3:45pm
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="relative group">
            <button
              disabled
              className="flex items-center gap-1.5 text-sm font-semibold rounded-lg px-3 py-2 cursor-not-allowed"
              style={{ background: "#f2f4f8", color: "#b0bdd0" }}
            >
              <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
                <circle cx="6" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.5" />
                <path
                  d="M1 13c0-2.76 2.24-5 5-5"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
                <path
                  d="M11 9v5M8.5 11.5h5"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
              Invite
            </button>
            <div
              className="absolute right-0 mt-1.5 px-3 py-2 rounded-lg text-xs whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-150"
              style={{
                top: "100%",
                background: "#1a2b4a",
                color: "#fff",
                boxShadow: "0 4px 14px rgba(0,0,0,0.18)",
                zIndex: 60,
              }}
            >
              Only the PM can invite new members
              <div
                style={{
                  position: "absolute",
                  top: -5,
                  right: 18,
                  width: 10,
                  height: 10,
                  background: "#1a2b4a",
                  transform: "rotate(45deg)",
                  borderRadius: 2,
                }}
              />
            </div>
          </div>

          {/* User dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen((v) => !v)}
              className="flex items-center gap-2 rounded-lg px-3 py-2 transition-colors"
              style={{
                background: dropdownOpen ? "#f0f5ff" : "transparent",
                border: "1.5px solid #e3ecff",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              }}
              onMouseLeave={(e) => {
                if (!dropdownOpen)
                  (e.currentTarget as HTMLElement).style.background = "transparent";
              }}
            >
              <div
                className="flex items-center justify-center rounded-full text-xs font-bold text-white shrink-0"
                style={{ width: 28, height: 28, background: "#1a6cff" }}
              >
                JD
              </div>
              <div className="flex flex-col items-start leading-none">
                <span className="text-xs font-semibold" style={{ color: "#0f1c3f" }}>
                  John Doe
                </span>
                <span className="text-xs" style={{ color: "#8fa8d0" }}>
                  UX · AI Workspace Project
                </span>
              </div>
              <svg
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                style={{
                  color: "#8fa8d0",
                  transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)",
                  transition: "transform 0.18s",
                }}
              >
                <path
                  d="M2 4l4 4 4-4"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {dropdownOpen && (
              <div
                className="absolute right-0 mt-1 rounded-xl overflow-hidden"
                style={{
                  top: "100%",
                  minWidth: 180,
                  background: "#fff",
                  border: "1.5px solid #e3ecff",
                  boxShadow: "0 8px 24px rgba(26,108,255,0.12)",
                  zIndex: 50,
                }}
              >
                <div
                  className="px-4 py-3"
                  style={{ borderBottom: "1px solid #e3ecff" }}
                >
                  <div className="text-sm font-semibold" style={{ color: "#0f1c3f" }}>
                    John Doe
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: "#8fa8d0" }}>
                    johndoe@rmit.edu.au
                  </div>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span
                      className="text-xs font-medium px-2 py-0.5 rounded-full"
                      style={{ background: "#e8f0ff", color: "#1a6cff" }}
                    >
                      UX
                    </span>
                    <span className="text-xs" style={{ color: "#b0c4de" }}>AI Workspace Project</span>
                  </div>
                </div>
                <button
                  className="w-full flex items-center gap-2.5 px-4 py-3 text-sm transition-colors text-left"
                  style={{ color: "#e03b3b" }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.background = "#fff5f5";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                  }}
                >
                  <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
                    <path
                      d="M6 2H3a1 1 0 00-1 1v9a1 1 0 001 1h3M10 10l3-2.5L10 5M13 7.5H6"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Chat area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Messages */}
        <div
          className="flex-1 overflow-y-auto"
          style={{ scrollbarWidth: "none" }}
        >
          <div className="max-w-3xl mx-auto px-4 py-6 flex flex-col gap-5">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
              >
                {msg.role === "assistant" && (
                  <div
                    className="flex items-center justify-center rounded-full shrink-0 text-white text-xs font-bold"
                    style={{
                      width: 34,
                      height: 34,
                      background: "linear-gradient(135deg, #1a6cff 0%, #0046cc 100%)",
                      boxShadow: "0 2px 8px rgba(26,108,255,0.3)",
                    }}
                  >
                    AI
                  </div>
                )}
                {msg.role === "user" && (
                  <div
                    className="flex items-center justify-center rounded-full shrink-0 text-white text-xs font-bold"
                    style={{
                      width: 34,
                      height: 34,
                      background: "#e3ecff",
                      color: "#1a6cff",
                    }}
                  >
                    JD
                  </div>
                )}
                <div
                  className={`flex flex-col gap-1 max-w-[75%] ${msg.role === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className="px-4 py-3 rounded-2xl text-sm leading-relaxed"
                    style={
                      msg.role === "user"
                        ? {
                            background: "#1a6cff",
                            color: "#fff",
                            borderBottomRightRadius: 4,
                          }
                        : {
                            background: "#fff",
                            color: "#1a2b4a",
                            border: "1.5px solid #e3ecff",
                            borderBottomLeftRadius: 4,
                            boxShadow: "0 1px 6px rgba(26,108,255,0.06)",
                          }
                    }
                  >
                    {msg.content}
                  </div>
                  <span className="text-xs" style={{ color: "#b0c4de" }}>
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input area */}
        <div
          className="shrink-0 px-4 pb-4 pt-3"
          style={{ background: "#f8faff" }}
        >
          <div
            className="max-w-3xl mx-auto rounded-2xl flex items-center gap-2 px-4 py-3"
            style={{
              background: "#fff",
              border: "1.5px solid #e3ecff",
              boxShadow: "0 2px 16px rgba(26,108,255,0.08)",
              transition: "box-shadow 0.2s",
            }}
            onFocusCapture={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 2px 20px rgba(26,108,255,0.16), 0 0 0 2px rgba(26,108,255,0.12)";
              (e.currentTarget as HTMLElement).style.borderColor = "#1a6cff";
            }}
            onBlurCapture={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 2px 16px rgba(26,108,255,0.08)";
              (e.currentTarget as HTMLElement).style.borderColor = "#e3ecff";
            }}
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={handleTextareaInput}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything"
              rows={1}
              className="flex-1 resize-none outline-none text-sm bg-transparent"
              style={{
                color: "#0f1c3f",
                maxHeight: 160,
                fontFamily: "'Inter', sans-serif",
                lineHeight: "1.5",
                display: "block",
                alignSelf: "center",
                paddingTop: 0,
                paddingBottom: 0,
              }}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim()}
              className="flex items-center justify-center rounded-xl shrink-0 transition-all"
              style={{
                width: 36,
                height: 36,
                background: input.trim() ? "#1a6cff" : "#e3ecff",
                color: input.trim() ? "#fff" : "#a0b8d8",
                cursor: input.trim() ? "pointer" : "default",
                transition: "background 0.18s, transform 0.12s",
              }}
              onMouseEnter={(e) => {
                if (input.trim())
                  (e.currentTarget as HTMLElement).style.transform = "scale(1.06)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = "scale(1)";
              }}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path
                  d="M13.5 8L3 3l2.5 5L3 13l10.5-5z"
                  fill="currentColor"
                />
              </svg>
            </button>
          </div>
          <p
            className="text-center text-xs mt-2"
            style={{ color: "#b0c4de" }}
          >
            Press Enter to send · Shift+Enter for new line
          </p>
        </div>
      </div>

      {/* Toast notification */}
      <div
        style={{
          position: "fixed",
          bottom: 28,
          right: 28,
          zIndex: 100,
          transform: toastVisible ? "translateY(0)" : "translateY(120%)",
          opacity: toastVisible ? 1 : 0,
          transition: "transform 0.35s cubic-bezier(0.4,0,0.2,1), opacity 0.3s",
          pointerEvents: toastVisible ? "auto" : "none",
        }}
      >
        <div
          className="flex items-start gap-3 rounded-2xl px-4 py-3.5"
          style={{
            background: "#fff",
            border: "1.5px solid #e3ecff",
            boxShadow: "0 8px 32px rgba(26,108,255,0.14), 0 2px 8px rgba(0,0,0,0.06)",
            minWidth: 280,
            maxWidth: 340,
          }}
        >
          <div
            className="flex items-center justify-center rounded-full shrink-0 mt-0.5"
            style={{ width: 32, height: 32, background: "#e8f0ff" }}
          >
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <path
                d="M7.5 1.5a6 6 0 100 12 6 6 0 000-12zM7.5 4v4M7.5 10h.01"
                stroke="#1a6cff"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold" style={{ color: "#0f1c3f" }}>
              New file shared
            </p>
            <p className="text-xs mt-0.5 leading-relaxed" style={{ color: "#6b87b0" }}>
              User 1 (PM) uploaded <span style={{ color: "#1a6cff", fontWeight: 600 }}>sprint_outline_v2.pdf</span> to the project.
            </p>
          </div>
          <button
            onClick={() => setToastVisible(false)}
            className="flex items-center justify-center rounded-lg shrink-0 transition-colors"
            style={{ width: 24, height: 24, color: "#b0c4de", marginTop: -2 }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              (e.currentTarget as HTMLElement).style.color = "#1a6cff";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
              (e.currentTarget as HTMLElement).style.color = "#b0c4de";
            }}
          >
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M9 3L3 9M3 3l6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      <style>{`
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
