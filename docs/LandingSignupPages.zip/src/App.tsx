import { useState } from "react";

type Page = "landing" | "login" | "signup";

export default function App() {
  const [page, setPage] = useState<Page>("landing");

  return (
    <div
      className="flex flex-col size-full overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif", background: "#f8faff" }}
    >
      {page === "landing" && <LandingPage onLogin={() => setPage("login")} onSignup={() => setPage("signup")} />}
      {page === "login" && <LoginPage onSignup={() => setPage("signup")} onBack={() => setPage("landing")} />}
      {page === "signup" && <SignupPage onLogin={() => setPage("login")} onBack={() => setPage("landing")} />}
      <style>{`::-webkit-scrollbar { display: none; }`}</style>
    </div>
  );
}

// Landing Page

function LandingPage({ onLogin, onSignup }: { onLogin: () => void; onSignup: () => void }) {
  const features = [
    {
      icon: (
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <rect x="3" y="3" width="16" height="16" rx="3" stroke="#1a6cff" strokeWidth="1.6" />
          <path d="M7 8h8M7 11h5M7 14h6" stroke="#1a6cff" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      ),
      title: "Project as source of truth",
      body: "Decisions, constraints, and requirements live in the project - not buried in one person's chat history.",
    },
    {
      icon: (
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <circle cx="11" cy="11" r="8" stroke="#1a6cff" strokeWidth="1.6" />
          <path d="M11 7v4.5l3 1.5" stroke="#1a6cff" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      title: "Every AI session starts informed",
      body: "When a teammate joins, their AI already knows the background, objectives, and prior decisions. No starting from zero.",
    },
    {
      icon: (
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <path d="M4 17l4-4 3 3 7-8" stroke="#1a6cff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="6" cy="6" r="2.5" stroke="#1a6cff" strokeWidth="1.4" />
          <circle cx="16" cy="6" r="2.5" stroke="#1a6cff" strokeWidth="1.4" />
          <path d="M8.5 6h5" stroke="#1a6cff" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      ),
      title: "Full attribution",
      body: "Every contribution is traceable - who added what, from which conversation, and when. No guessing where a decision came from.",
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
      {/* Header */}
      <header
        className="flex items-center px-6 shrink-0"
        style={{
          height: 58,
          background: "#fff",
          borderBottom: "1.5px solid #e3ecff",
          position: "sticky",
          top: 0,
          zIndex: 10,
        }}
      >
        <div className="flex items-center gap-2 mr-auto">
          <div
            className="flex items-center justify-center rounded-xl text-white text-xs font-bold shrink-0"
            style={{ width: 32, height: 32, background: "linear-gradient(135deg, #1a6cff 0%, #0046cc 100%)" }}
          >
            AI
          </div>
          <span className="font-semibold text-sm" style={{ color: "#0f1c3f" }}>
            NBN UX AI
          </span>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onLogin}
            className="rounded-xl px-4 py-2 text-sm font-semibold transition-all"
            style={{ color: "#1a6cff", border: "1.5px solid #e3ecff", background: "#fff" }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#f0f5ff"; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "#fff"; }}
          >
            Sign in
          </button>
          <button
            onClick={onSignup}
            className="rounded-xl px-4 py-2 text-sm font-semibold transition-all"
            style={{ background: "#1a6cff", color: "#fff", boxShadow: "0 2px 10px rgba(26,108,255,0.28)" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#1460e8";
              (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(26,108,255,0.38)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#1a6cff";
              (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 10px rgba(26,108,255,0.28)";
            }}
          >
            Create account
          </button>
        </div>
      </header>

      {/* Hero */}
      <div className="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
        <h1
          className="font-bold leading-tight mb-6"
          style={{ color: "#0f1c3f", fontSize: "clamp(2rem, 5vw, 3.25rem)", letterSpacing: "-0.02em" }}
        >
          NBN UX Using AI&#8202;—&#8202;Team1
        </h1>

        <p
          className="mx-auto leading-relaxed mb-12"
          style={{ color: "#4a6fa5", fontSize: "1.0625rem", maxWidth: 580 }}
        >
          Normal AI chats trap knowledge inside individual conversations. We turn the project into the
          source of truth so everyone's AI works from the same background, decisions, and constraints,
          with full traceability.
        </p>

        {/* CTA buttons */}
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <button
            onClick={onSignup}
            className="flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-semibold transition-all"
            style={{ background: "#1a6cff", color: "#fff", boxShadow: "0 4px 18px rgba(26,108,255,0.34)" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#1460e8";
              (e.currentTarget as HTMLElement).style.boxShadow = "0 6px 24px rgba(26,108,255,0.42)";
              (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#1a6cff";
              (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 18px rgba(26,108,255,0.34)";
              (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
            }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M7 1.5v11M1.5 7h11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            Create account
          </button>
          <button
            onClick={onLogin}
            className="flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-semibold transition-all"
            style={{ color: "#1a6cff", border: "1.5px solid #d0e0ff", background: "#fff" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f0f5ff";
              (e.currentTarget as HTMLElement).style.borderColor = "#b8d0ff";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#fff";
              (e.currentTarget as HTMLElement).style.borderColor = "#d0e0ff";
            }}
          >
            Sign in
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M2.5 6.5h8M7 3l3.5 3.5L7 10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      </div>

      {/* Feature cards */}
      <div
        className="max-w-4xl mx-auto px-6 pb-20"
        style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "1.25rem" }}
      >
        {features.map((f, i) => (
          <FeatureCard key={i} icon={f.icon} title={f.title} body={f.body} />
        ))}
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className="rounded-2xl p-6 flex flex-col gap-4 transition-all"
      style={{
        background: "#fff",
        border: `1.5px solid ${hovered ? "#b8d0ff" : "#e3ecff"}`,
        boxShadow: hovered ? "0 8px 28px rgba(26,108,255,0.13)" : "0 1px 6px rgba(26,108,255,0.05)",
        transition: "border-color 0.18s, box-shadow 0.18s",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        className="flex items-center justify-center rounded-xl shrink-0"
        style={{ width: 44, height: 44, background: "#eef3ff" }}
      >
        {icon}
      </div>
      <div>
        <h3 className="text-sm font-bold mb-2 leading-snug" style={{ color: "#0f1c3f" }}>{title}</h3>
        <p className="text-sm leading-relaxed" style={{ color: "#4a6fa5" }}>{body}</p>
      </div>
    </div>
  );
}

// Shared Auth Shell

function AuthShell({ children, onBack }: { children: React.ReactNode; onBack: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      {/* Minimal header */}
      <header
        className="flex items-center px-6 shrink-0"
        style={{ height: 58, background: "#fff", borderBottom: "1.5px solid #e3ecff" }}
      >
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-medium transition-colors mr-auto"
          style={{ color: "#8fa8d0" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "#1a6cff"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "#8fa8d0"; }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M10 3L5.5 8 10 13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Back
        </button>
        <div className="flex items-center gap-2">
          <div
            className="flex items-center justify-center rounded-xl text-white text-xs font-bold shrink-0"
            style={{ width: 28, height: 28, background: "linear-gradient(135deg, #1a6cff 0%, #0046cc 100%)" }}
          >
            AI
          </div>
          <span className="font-semibold text-sm" style={{ color: "#0f1c3f" }}>NBN UX AI</span>
        </div>
      </header>

      {/* Centered card */}
      <div className="flex-1 flex items-center justify-center px-4 py-10">
        <div
          className="w-full rounded-2xl px-8 py-8"
          style={{
            maxWidth: 420,
            background: "#fff",
            border: "1.5px solid #e3ecff",
            boxShadow: "0 8px 36px rgba(26,108,255,0.1)",
          }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}

// Form primitives

function FormField({
  label,
  type = "text",
  placeholder,
  autoComplete,
  value,
  onChange,
  error,
}: {
  label: string;
  type?: string;
  placeholder: string;
  autoComplete?: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
}) {
  const [focused, setFocused] = useState(false);
  const borderColor = error ? "#e03b3b" : focused ? "#1a6cff" : "#e3ecff";
  const shadow = error
    ? "0 0 0 3px rgba(224,59,59,0.1)"
    : focused
    ? "0 0 0 3px rgba(26,108,255,0.1)"
    : "none";
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold" style={{ color: "#4a6fa5" }}>{label}</label>
      <input
        type={type}
        placeholder={placeholder}
        autoComplete={autoComplete}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-all"
        style={{
          border: `1.5px solid ${borderColor}`,
          background: focused ? "#fff" : "#f8faff",
          color: "#0f1c3f",
          fontFamily: "'Inter', sans-serif",
          boxShadow: shadow,
        }}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />
      {error && (
        <p className="text-xs" style={{ color: "#e03b3b" }}>{error}</p>
      )}
    </div>
  );
}

function PrimaryButton({ children }: { children: React.ReactNode }) {
  return (
    <button
      type="submit"
      className="w-full rounded-xl py-3 text-sm font-semibold transition-all"
      style={{ background: "#1a6cff", color: "#fff", boxShadow: "0 2px 10px rgba(26,108,255,0.28)" }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.background = "#1460e8";
        (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(26,108,255,0.38)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.background = "#1a6cff";
        (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 10px rgba(26,108,255,0.28)";
      }}
    >
      {children}
    </button>
  );
}

// Login Page

function LoginPage({ onSignup, onBack }: { onSignup: () => void; onBack: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const next: typeof errors = {};
    if (!email.trim()) next.email = "Email is required";
    if (!password) next.password = "Password is required";
    setErrors(next);
  }

  return (
    <AuthShell onBack={onBack}>
      <div className="mb-7">
        <h1 className="text-xl font-bold mb-1" style={{ color: "#0f1c3f" }}>Sign in</h1>
        <p className="text-sm" style={{ color: "#8fa8d0" }}>Enter your credentials to continue</p>
      </div>

      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <FormField
          label="Email"
          type="email"
          placeholder="you@example.com"
          autoComplete="email"
          value={email}
          onChange={(v) => { setEmail(v); setErrors((p) => ({ ...p, email: undefined })); }}
          error={errors.email}
        />
        <FormField
          label="Password"
          type="password"
          placeholder="••••••••"
          autoComplete="current-password"
          value={password}
          onChange={(v) => { setPassword(v); setErrors((p) => ({ ...p, password: undefined })); }}
          error={errors.password}
        />
        <div className="mt-1">
          <PrimaryButton>Sign in</PrimaryButton>
        </div>
      </form>

      <p className="text-sm text-center mt-5" style={{ color: "#8fa8d0" }}>
        Don't have an account?{" "}
        <button
          onClick={onSignup}
          className="font-semibold transition-colors"
          style={{ color: "#1a6cff", textDecoration: "underline", background: "none", border: "none", cursor: "pointer", padding: 0 }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "#0046cc"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "#1a6cff"; }}
        >
          Create one
        </button>
      </p>
    </AuthShell>
  );
}

// Signup Page

function validatePassword(pw: string): string | undefined {
  if (!pw) return "Password is required";
  if (pw.length < 8) return "Must be at least 8 characters";
  if (!/[A-Z]/.test(pw)) return "Must contain at least 1 uppercase letter";
  if (!/[0-9]/.test(pw)) return "Must contain at least 1 number";
}

function SignupPage({ onLogin, onBack }: { onLogin: () => void; onBack: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<{
    name?: string; email?: string; password?: string; confirm?: string;
  }>({});

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Name is required";
    if (!email.trim()) next.email = "Email is required";
    const pwErr = validatePassword(password);
    if (pwErr) next.password = pwErr;
    if (!confirm) next.confirm = "Please confirm your password";
    else if (confirm !== password) next.confirm = "Passwords do not match";
    setErrors(next);
  }

  return (
    <AuthShell onBack={onBack}>
      <div className="mb-7">
        <h1 className="text-xl font-bold mb-1" style={{ color: "#0f1c3f" }}>Create account</h1>
        <p className="text-sm" style={{ color: "#8fa8d0" }}>Get started for free</p>
      </div>

      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <FormField
          label="Name"
          placeholder="Your full name"
          autoComplete="name"
          value={name}
          onChange={(v) => { setName(v); setErrors((p) => ({ ...p, name: undefined })); }}
          error={errors.name}
        />
        <FormField
          label="Email"
          type="email"
          placeholder="you@example.com"
          autoComplete="email"
          value={email}
          onChange={(v) => { setEmail(v); setErrors((p) => ({ ...p, email: undefined })); }}
          error={errors.email}
        />
        <FormField
          label="Password"
          type="password"
          placeholder="Min. 8 characters, 1 uppercase, 1 number"
          autoComplete="new-password"
          value={password}
          onChange={(v) => { setPassword(v); setErrors((p) => ({ ...p, password: undefined })); }}
          error={errors.password}
        />
        <FormField
          label="Confirm password"
          type="password"
          placeholder="••••••••"
          autoComplete="new-password"
          value={confirm}
          onChange={(v) => { setConfirm(v); setErrors((p) => ({ ...p, confirm: undefined })); }}
          error={errors.confirm}
        />
        <div className="mt-1">
          <PrimaryButton>Create account</PrimaryButton>
        </div>
      </form>

      <p className="text-sm text-center mt-5" style={{ color: "#8fa8d0" }}>
        Already have an account?{" "}
        <button
          onClick={onLogin}
          className="font-semibold transition-colors"
          style={{ color: "#1a6cff", textDecoration: "underline", background: "none", border: "none", cursor: "pointer", padding: 0 }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "#0046cc"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "#1a6cff"; }}
        >
          Sign in
        </button>
      </p>
    </AuthShell>
  );
}
