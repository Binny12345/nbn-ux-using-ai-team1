import { useState, useRef, useEffect } from "react";

type SortKey = "az" | "za" | "recent";

type Project = {
  id: number;
  title: string;
  lastEdited: string;
  lastAccessedAt: number;
  members: number;
  role: "PM" | "UX" | "BA" | "Dev";
  initials: string;
  color: string;
};

const INITIAL_PROJECTS: Project[] = [
  {
    id: 1,
    title: "AI Workspace Project",
    lastEdited: "Today at 3:45pm",
    lastAccessedAt: Date.now() - 1000 * 60 * 30,
    members: 5,
    role: "PM",
    initials: "AI",
    color: "#1a6cff",
  },
  {
    id: 2,
    title: "Example Project",
    lastEdited: "Yesterday at 11:20am",
    lastAccessedAt: Date.now() - 1000 * 60 * 60 * 26,
    members: 3,
    role: "UX",
    initials: "EX",
    color: "#6c3fff",
  },

];

export default function App() {
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [sortKey, setSortKey] = useState<SortKey>("recent");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);

  // Leave confirmation
  const [leaveTarget, setLeaveTarget] = useState<Project | null>(null);

  // Add project modal
  const [addOpen, setAddOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const addInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (addOpen) {
      setTimeout(() => addInputRef.current?.focus(), 50);
    }
  }, [addOpen]);

  function confirmDelete() {
    if (!deleteTarget) return;
    setProjects((prev) => prev.filter((p) => p.id !== deleteTarget.id));
    setDeleteTarget(null);
  }

  function confirmLeave() {
    if (!leaveTarget) return;
    setProjects((prev) => prev.filter((p) => p.id !== leaveTarget.id));
    setLeaveTarget(null);
  }

  const sortedProjects = [...projects].sort((a, b) => {
    if (sortKey === "az") return a.title.localeCompare(b.title);
    if (sortKey === "za") return b.title.localeCompare(a.title);
    return b.lastAccessedAt - a.lastAccessedAt;
  });

  function handleAddProject() {
    const title = newTitle.trim();
    if (!title) return;
    const colors = ["#1a6cff", "#6c3fff", "#0099aa", "#d4600a", "#1a9e5c", "#b0006e"];
    const color = colors[projects.length % colors.length];
    const words = title.split(" ").filter(Boolean);
    const initials = words.length >= 2
      ? (words[0][0] + words[1][0]).toUpperCase()
      : title.slice(0, 2).toUpperCase();
    setProjects((prev) => [
      ...prev,
      {
        id: Date.now(),
        title,
        lastEdited: "Just now",
        lastAccessedAt: Date.now(),
        members: 1,
        role: "PM",
        initials,
        color,
      },
    ]);
    setNewTitle("");
    setAddOpen(false);
  }

  function handleAddKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") handleAddProject();
    if (e.key === "Escape") { setAddOpen(false); setNewTitle(""); }
  }

  const modalOpen = !!deleteTarget || !!leaveTarget || addOpen;

  return (
    <div
      className="flex flex-col size-full overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif", background: "#f8faff" }}
    >
      {/* Header */}
      <header
        className="flex items-center px-6 shrink-0"
        style={{
          height: 58,
          background: "#fff",
          borderBottom: "1.5px solid #e3ecff",
          zIndex: 10,
        }}
      >
        {/* Logo / brand */}
        <div className="flex items-center gap-2 mr-auto">
          <div
            className="flex items-center justify-center rounded-xl text-white text-xs font-bold shrink-0"
            style={{ width: 32, height: 32, background: "linear-gradient(135deg, #1a6cff 0%, #0046cc 100%)" }}
          >
            AI
          </div>
          <span className="font-semibold text-sm" style={{ color: "#0f1c3f" }}>
            Multi-user AI
          </span>
        </div>

        {/* Add project button */}
        <button
          onClick={() => setAddOpen(true)}
          className="flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold mr-3 transition-all"
          style={{
            background: "#1a6cff",
            color: "#fff",
            boxShadow: "0 2px 10px rgba(26,108,255,0.28)",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.background = "#1460e8";
            (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(26,108,255,0.38)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.background = "#1a6cff";
            (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 10px rgba(26,108,255,0.28)";
          }}
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M7 1.5v11M1.5 7h11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          New Project
        </button>

        {/* User dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen((v) => !v)}
            className="flex items-center gap-2 rounded-lg px-3 py-2 transition-colors"
            style={{
              background: dropdownOpen ? "#f0f5ff" : "transparent",
              border: "1.5px solid #e3ecff",
            }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#f0f5ff"; }}
            onMouseLeave={(e) => { if (!dropdownOpen) (e.currentTarget as HTMLElement).style.background = "transparent"; }}
          >
            <div
              className="flex items-center justify-center rounded-full text-xs font-bold text-white shrink-0"
              style={{ width: 28, height: 28, background: "#1a6cff" }}
            >
              JD
            </div>
            <div className="flex flex-col items-start leading-none">
              <span className="text-xs font-semibold" style={{ color: "#0f1c3f" }}>John Doe</span>
              <span className="text-xs" style={{ color: "#8fa8d0" }}>johndoe@rmit.edu.au</span>
            </div>
            <svg
              width="12" height="12" viewBox="0 0 12 12" fill="none"
              style={{ color: "#8fa8d0", transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.18s" }}
            >
              <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          {dropdownOpen && (
            <div
              className="absolute right-0 mt-1 rounded-xl overflow-hidden"
              style={{
                top: "100%",
                minWidth: 180,
                background: "#fff",
                border: "1.5px solid #e3ecff",
                boxShadow: "0 8px 24px rgba(26,108,255,0.12)",
                zIndex: 50,
              }}
            >
              <div className="px-4 py-3" style={{ borderBottom: "1px solid #e3ecff" }}>
                <div className="text-sm font-semibold" style={{ color: "#0f1c3f" }}>John Doe</div>
                <div className="text-xs mt-0.5" style={{ color: "#8fa8d0" }}>johndoe@rmit.edu.au</div>
              </div>
              <button
                className="w-full flex items-center gap-2.5 px-4 py-3 text-sm transition-colors text-left"
                style={{ color: "#e03b3b" }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#fff5f5"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
              >
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
                  <path d="M6 2H3a1 1 0 00-1 1v9a1 1 0 001 1h3M10 10l3-2.5L10 5M13 7.5H6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Log out
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        <div className="max-w-5xl mx-auto px-6 py-8">
          {/* Page title + sort */}
          <div className="flex items-center justify-between mb-7">
            <div>
              <h1 className="text-xl font-bold" style={{ color: "#0f1c3f" }}>My Projects</h1>
              <p className="text-sm mt-1" style={{ color: "#8fa8d0" }}>
                {projects.length} project{projects.length !== 1 ? "s" : ""}
              </p>
            </div>
            <div className="flex items-center gap-1 rounded-xl p-1" style={{ background: "#eef3ff", border: "1.5px solid #e3ecff" }}>
              {([
                { key: "recent" as SortKey, label: "Recent" },
                { key: "az" as SortKey, label: "A–Z" },
                { key: "za" as SortKey, label: "Z–A" },
              ] as { key: SortKey; label: string }[]).map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setSortKey(key)}
                  className="rounded-lg px-3 py-1.5 text-xs font-semibold transition-all"
                  style={{
                    background: sortKey === key ? "#fff" : "transparent",
                    color: sortKey === key ? "#1a6cff" : "#8fa8d0",
                    boxShadow: sortKey === key ? "0 1px 4px rgba(26,108,255,0.12)" : "none",
                    border: sortKey === key ? "1px solid #d6e6ff" : "1px solid transparent",
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Project grid */}
          {projects.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center rounded-2xl py-20 text-center"
              style={{ border: "1.5px dashed #c8d9f5", background: "#fff" }}
            >
              <div
                className="flex items-center justify-center rounded-full mb-4"
                style={{ width: 52, height: 52, background: "#eef3ff" }}
              >
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                  <rect x="3" y="3" width="16" height="16" rx="3" stroke="#1a6cff" strokeWidth="1.6" />
                  <path d="M11 7.5v7M7.5 11h7" stroke="#1a6cff" strokeWidth="1.6" strokeLinecap="round" />
                </svg>
              </div>
              <p className="text-sm font-semibold" style={{ color: "#0f1c3f" }}>No projects yet</p>
              <p className="text-xs mt-1 mb-5" style={{ color: "#8fa8d0" }}>Create your first project to get started</p>
              <button
                onClick={() => setAddOpen(true)}
                className="flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition-all"
                style={{ background: "#1a6cff", color: "#fff" }}
              >
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                  <path d="M6.5 1.5v10M1.5 6.5h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                New Project
              </button>
            </div>
          ) : (
            <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))" }}>
              {sortedProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onDelete={() => setDeleteTarget(project)}
                  onLeave={() => setLeaveTarget(project)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modal backdrop */}
      {modalOpen && (
        <div
          className="fixed inset-0 flex items-center justify-center"
          style={{ background: "rgba(15,28,63,0.38)", zIndex: 60, backdropFilter: "blur(2px)" }}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setDeleteTarget(null);
              setLeaveTarget(null);
              setAddOpen(false);
              setNewTitle("");
            }
          }}
        >
          {/* Delete confirmation */}
          {deleteTarget && (
            <ConfirmModal
              icon={
                <div
                  className="flex items-center justify-center rounded-full"
                  style={{ width: 48, height: 48, background: "#fff1f1" }}
                >
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <path d="M4 6h14M9 6V4h4v2M8 10v6M14 10v6M5 6l1 12a1 1 0 001 1h8a1 1 0 001-1l1-12" stroke="#e03b3b" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              }
              title="Delete project?"
              description={
                <>
                  This will permanently delete{" "}
                  <span style={{ color: "#0f1c3f", fontWeight: 600 }}>{deleteTarget.title}</span>{" "}
                  and all its data. This action cannot be undone.
                </>
              }
              confirmLabel="Delete Project"
              confirmStyle={{ background: "#e03b3b", color: "#fff" }}
              confirmHoverStyle={{ background: "#c82e2e" }}
              onConfirm={confirmDelete}
              onCancel={() => setDeleteTarget(null)}
            />
          )}

          {/* Leave confirmation */}
          {leaveTarget && (
            <ConfirmModal
              icon={
                <div
                  className="flex items-center justify-center rounded-full"
                  style={{ width: 48, height: 48, background: "#fff7ed" }}
                >
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <path d="M9 4H5a1 1 0 00-1 1v12a1 1 0 001 1h4M15 15l4-4-4-4M19 11H9" stroke="#d4600a" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              }
              title="Leave project?"
              description={
                <>
                  You will lose access to{" "}
                  <span style={{ color: "#0f1c3f", fontWeight: 600 }}>{leaveTarget.title}</span>.{" "}
                  The project manager will need to re-invite you to regain access.
                </>
              }
              confirmLabel="Leave Project"
              confirmStyle={{ background: "#d4600a", color: "#fff" }}
              confirmHoverStyle={{ background: "#b84e07" }}
              onConfirm={confirmLeave}
              onCancel={() => setLeaveTarget(null)}
            />
          )}

          {/* Add project modal */}
          {addOpen && (
            <div
              className="rounded-2xl px-7 py-6 flex flex-col gap-5"
              style={{
                background: "#fff",
                border: "1.5px solid #e3ecff",
                boxShadow: "0 20px 60px rgba(26,108,255,0.18)",
                width: 420,
                maxWidth: "90vw",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3">
                <div
                  className="flex items-center justify-center rounded-full shrink-0"
                  style={{ width: 48, height: 48, background: "#eef3ff" }}
                >
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <rect x="3" y="3" width="16" height="16" rx="3" stroke="#1a6cff" strokeWidth="1.6" />
                    <path d="M11 7.5v7M7.5 11h7" stroke="#1a6cff" strokeWidth="1.6" strokeLinecap="round" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-base font-bold" style={{ color: "#0f1c3f" }}>New Project</h2>
                  <p className="text-xs mt-0.5" style={{ color: "#8fa8d0" }}>Please select a name</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1.5 tracking-wide" style={{ color: "#4a6fa5", letterSpacing: "0.05em" }}>
                  PROJECT NAME
                </label>
                <input
                  ref={addInputRef}
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  onKeyDown={handleAddKeyDown}
                  className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-all"
                  style={{
                    border: "1.5px solid #e3ecff",
                    background: "#f8faff",
                    color: "#0f1c3f",
                    fontFamily: "'Inter', sans-serif",
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = "#1a6cff";
                    e.currentTarget.style.boxShadow = "0 0 0 3px rgba(26,108,255,0.1)";
                    e.currentTarget.style.background = "#fff";
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = "#e3ecff";
                    e.currentTarget.style.boxShadow = "none";
                    e.currentTarget.style.background = "#f8faff";
                  }}
                />
                <p className="text-xs mt-2 flex items-center gap-1.5" style={{ color: "#8fa8d0" }}>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <circle cx="6" cy="6" r="5" stroke="#1a6cff" strokeWidth="1.2" />
                    <path d="M6 5.5v3M6 4h.01" stroke="#1a6cff" strokeWidth="1.2" strokeLinecap="round" />
                  </svg>
                  <span>You will be assigned as <span style={{ color: "#1a6cff", fontWeight: 600 }}>Project Manager</span> for this project.</span>
                </p>
              </div>

              <div className="flex gap-2.5">
                <button
                  onClick={() => { setAddOpen(false); setNewTitle(""); }}
                  className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-colors"
                  style={{ background: "#f0f5ff", color: "#4a6fa5", border: "1.5px solid #e3ecff" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#e3ecff"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "#f0f5ff"; }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddProject}
                  disabled={!newTitle.trim()}
                  className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all"
                  style={{
                    background: newTitle.trim() ? "#1a6cff" : "#c8d9f5",
                    color: "#fff",
                    cursor: newTitle.trim() ? "pointer" : "default",
                    boxShadow: newTitle.trim() ? "0 2px 10px rgba(26,108,255,0.28)" : "none",
                  }}
                  onMouseEnter={(e) => { if (newTitle.trim()) (e.currentTarget as HTMLElement).style.background = "#1460e8"; }}
                  onMouseLeave={(e) => { if (newTitle.trim()) (e.currentTarget as HTMLElement).style.background = "#1a6cff"; }}
                >
                  Create Project
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      <style>{`
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}

function ProjectCard({
  project,
  onDelete,
  onLeave,
}: {
  project: Project;
  onDelete: () => void;
  onLeave: () => void;
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className="rounded-2xl flex flex-col cursor-pointer transition-all"
      style={{
        background: "#fff",
        border: `1.5px solid ${hovered ? "#b8d0ff" : "#e3ecff"}`,
        boxShadow: hovered
          ? "0 8px 28px rgba(26,108,255,0.13)"
          : "0 1px 6px rgba(26,108,255,0.05)",
        transition: "border-color 0.18s, box-shadow 0.18s",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Card top click zone */}
      <div className="flex-1 p-5">
        {/* Avatar + role badge */}
        <div className="flex items-start justify-between mb-4">
          <div
            className="flex items-center justify-center rounded-xl text-white text-sm font-bold shrink-0"
            style={{ width: 44, height: 44, background: project.color }}
          >
            {project.initials}
          </div>
          <span
            className="text-xs font-semibold px-2.5 py-1 rounded-full"
            style={
              project.role === "PM"
                ? { background: "#eef3ff", color: "#1a6cff" }
                : { background: "#f4f6fb", color: "#6b87b0" }
            }
          >
            {project.role === "PM" ? "Project Manager" : "UX"}
          </span>
        </div>

        <h3 className="text-sm font-bold leading-snug mb-1.5" style={{ color: "#0f1c3f" }}>
          {project.title}
        </h3>

        <div className="flex items-center gap-3">
          <span className="text-xs flex items-center gap-1" style={{ color: "#8fa8d0" }}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <circle cx="6" cy="4" r="2" stroke="currentColor" strokeWidth="1.2" />
              <path d="M1 11c0-2.76 2.24-5 5-5s5 2.24 5 5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
            </svg>
            {project.members} member{project.members !== 1 ? "s" : ""}
          </span>
          <span className="text-xs flex items-center gap-1" style={{ color: "#8fa8d0" }}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <rect x="1" y="2" width="10" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.2" />
              <path d="M1 5h10M4 1v2M8 1v2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
            </svg>
            {project.lastEdited}
          </span>
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: "1.5px", background: "#e3ecff", margin: "0 20px" }} />

      {/* Action row */}
      <div className="flex items-center justify-between px-5 py-3">
        <span className="text-xs font-medium" style={{ color: "#8fa8d0" }}>
          Click card to open →
        </span>
        {project.role === "PM" ? (
          <button
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors"
            style={{ color: "#e03b3b", background: "transparent" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#fff1f1";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
            }}
          >
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M2.5 3.5h8M5 3.5V2.5h3v1M4.5 5.5l.5 4M8.5 5.5l-.5 4M3 3.5l.8 7a.5.5 0 00.5.5h4.4a.5.5 0 00.5-.5L10 3.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Delete
          </button>
        ) : (
          <button
            onClick={(e) => { e.stopPropagation(); onLeave(); }}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors"
            style={{ color: "#8fa8d0", background: "transparent" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "#f4f6fb";
              (e.currentTarget as HTMLElement).style.color = "#4a6fa5";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
              (e.currentTarget as HTMLElement).style.color = "#8fa8d0";
            }}
          >
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M5.5 2.5H3a.5.5 0 00-.5.5v7a.5.5 0 00.5.5h2.5M9 9l3-2.5L9 4M12 6.5H5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Leave
          </button>
        )}
      </div>
    </div>
  );
}

function ConfirmModal({
  icon,
  title,
  description,
  confirmLabel,
  confirmStyle,
  confirmHoverStyle,
  onConfirm,
  onCancel,
}: {
  icon: React.ReactNode;
  title: string;
  description: React.ReactNode;
  confirmLabel: string;
  confirmStyle: React.CSSProperties;
  confirmHoverStyle: React.CSSProperties;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div
      className="rounded-2xl px-7 py-6 flex flex-col gap-5"
      style={{
        background: "#fff",
        border: "1.5px solid #e3ecff",
        boxShadow: "0 20px 60px rgba(26,108,255,0.18)",
        width: 400,
        maxWidth: "90vw",
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center gap-4">
        {icon}
        <div>
          <h2 className="text-base font-bold" style={{ color: "#0f1c3f" }}>{title}</h2>
        </div>
      </div>
      <p className="text-sm leading-relaxed" style={{ color: "#4a6fa5" }}>
        {description}
      </p>
      <div className="flex gap-2.5">
        <button
          onClick={onCancel}
          className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-colors"
          style={{ background: "#f0f5ff", color: "#4a6fa5", border: "1.5px solid #e3ecff" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#e3ecff"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "#f0f5ff"; }}
        >
          Cancel
        </button>
        <ConfirmButton label={confirmLabel} base={confirmStyle} hover={confirmHoverStyle} onClick={onConfirm} />
      </div>
    </div>
  );
}

function ConfirmButton({
  label,
  base,
  hover,
  onClick,
}: {
  label: string;
  base: React.CSSProperties;
  hover: React.CSSProperties;
  onClick: () => void;
}) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onClick}
      className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all"
      style={{ ...base, ...(hov ? hover : {}) }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
    >
      {label}
    </button>
  );
}
